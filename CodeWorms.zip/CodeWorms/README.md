# code-worms

Team Members:

1- Bassem mohamed (28-4904)
  mail: bassemmohamed1994@gmail.com
  
2- Ahmed Hany (28-8064)
  mail: klbala2007@gmail.com
  
3- Amr hazem
  mail:
  
4- Yousef Ihab (31-5781)
  mail: youssefgam95@gmail.com
  
5- Moustafa mahmoud (31-7344)  mail: Moustafa.Mahm@gmail.com

  
6- Moustafa nagy
  mail:
  
7- Ahmad el nashar
  mail: 

These team members are working to create a one-page responsive website to book, track and view flights from Egypt Airlines using the MEAN stack ( NodeJS , Angular , MongoDB ).
