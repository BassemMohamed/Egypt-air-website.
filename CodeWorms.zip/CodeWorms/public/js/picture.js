$(document).ready(function(){
alert();

});