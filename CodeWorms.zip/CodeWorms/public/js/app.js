//app.js 
angular.module('EgyptAirlines', ['ngRoute', 'appRoutes', 'mainController', 'viewFlightsController', 'viewFlightsService']);