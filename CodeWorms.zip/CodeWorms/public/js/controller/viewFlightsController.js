// viewFlightsController

angular.module('viewFlightsController', []).controller('ViewFlightsController', function($scope) 
{
    $scope.tagline = 'Nothing beats a pocket protector!';
});