//Main Controller

angular.module('mainController', []).controller('mainController', function($scope) 
{
    console.log("haha");   
});